**/ Registration Module FREE Version \**
**/ Module by Mubeen & Gigabait for Pterodactyl 1.4.x \**

Before proceeding with installation make sure you have checked the following things:

* Make sure you're running the latest version of Pterodactyl
* This Module works with the Unix theme, please contact Mubeen to get the files for the theme.

Installation:

1. Open the "Pterodactyl" Folder found in this directory
2. Upload all the folders into /var/www/pterodactyl
3. You're done! The form can be found at https://domain.com/auth/register

Need help? Join our discord: https://discord.gg/RJfCxC2W3e